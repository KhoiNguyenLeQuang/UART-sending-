/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "string.h"
#include "stdlib.h"
#include <stdio.h>
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
float temperatures[] = { 23.56f, 18.75f, 29.32f };
union {
	float f;
	uint8_t u8[4];
} float_union;

// ================= THÊM MỚI =================
// Định nghĩa thứ tự byte của float khi gửi Modbus
typedef enum {
	MB_ABCD, // big-endian bytes
	MB_BADC, // như code hiện tại
	MB_CDAB,
	MB_DCBA
} mb_float_order_t;

// Hàm encode float sang 4 byte theo thứ tự order
static inline void encode_float_to_regs(uint8_t *dst, union {
	float f;
	uint8_t b[4];
} fu, mb_float_order_t order) {
	switch (order) {
	case MB_ABCD:
		dst[0] = fu.b[0];
		dst[1] = fu.b[1];
		dst[2] = fu.b[2];
		dst[3] = fu.b[3];
		break;
	case MB_BADC:
		dst[0] = fu.b[1];
		dst[1] = fu.b[0];
		dst[2] = fu.b[3];
		dst[3] = fu.b[2];
		break;
	case MB_CDAB:
		dst[0] = fu.b[2];
		dst[1] = fu.b[3];
		dst[2] = fu.b[0];
		dst[3] = fu.b[1];
		break;
	case MB_DCBA:
		dst[0] = fu.b[3];
		dst[1] = fu.b[2];
		dst[2] = fu.b[1];
		dst[3] = fu.b[0];
		break;
	}
}
// =============================================

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */
// Prototype mới dùng cho Modbus
uint16_t ModRTU_CRC(uint8_t *buf, int len);
HAL_StatusTypeDef Modbus_ReadAck_0x10(UART_HandleTypeDef *huart,
		uint8_t expected_slave, uint16_t expected_start_addr,
		uint16_t expected_qty_reg, uint32_t timeout_ms);
HAL_StatusTypeDef Send_ModbusRTU_Floats(UART_HandleTypeDef *huart,
		const float *vals, uint8_t count, uint16_t start_addr,
		mb_float_order_t order);
HAL_StatusTypeDef Send_ModbusRTU_Float(UART_HandleTypeDef *huart, float value,
		uint16_t start_addr);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void Serial_Monitor(uint32_t step_send) {
	static uint32_t time_Uart = 0;
	static uint8_t TxData[300];
	if (HAL_GetTick() - time_Uart > step_send) {
		time_Uart = HAL_GetTick();

		for (int i = 0; i < sizeof(temperatures) / sizeof(float); i++) {
			sprintf((char*) TxData, "Temp[%d] = %.2f\n", i, temperatures[i]);
			HAL_UART_Transmit(&huart1, TxData, strlen((char*) TxData), 10);
		}
		HAL_UART_Transmit(&huart1, TxData, strlen((char*) TxData), 10);
	}
}
/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void) {
	HAL_Init();
	SystemClock_Config();
	MX_GPIO_Init();
	MX_USART1_UART_Init();

	/* USER CODE BEGIN 2 */
	/* USER CODE END 2 */

	while (1) {
		/* USER CODE BEGIN 3 */

		// ======= Gọi hàm mới để gửi nhiều float một lần =======
		if (Send_ModbusRTU_Floats(&huart1, temperatures, 3, 0x0010, MB_BADC)
				!= HAL_OK) {
			// TODO: retry hoặc báo lỗi
		}
		HAL_Delay(1000);

		/* USER CODE END 3 */
	}
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };

	__HAL_RCC_PWR_CLK_ENABLE();
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}

	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) {
		Error_Handler();
	}
}

static void MX_USART1_UART_Init(void) {
	huart1.Instance = USART1;
	huart1.Init.BaudRate = 115200;
	huart1.Init.WordLength = UART_WORDLENGTH_8B;
	huart1.Init.StopBits = UART_STOPBITS_1;
	huart1.Init.Parity = UART_PARITY_NONE;
	huart1.Init.Mode = UART_MODE_TX_RX;
	huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart1.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&huart1) != HAL_OK) {
		Error_Handler();
	}
}

static void MX_GPIO_Init(void) {
	__HAL_RCC_GPIOA_CLK_ENABLE();
}

/* USER CODE BEGIN 4 */
// CRC16 MODBUS calculation (bản mới)
uint16_t ModRTU_CRC(uint8_t buf[], int len) {
	uint16_t crc = 0xFFFF;
	for (int pos = 0; pos < len; pos++) {
		crc ^= (uint16_t) buf[pos];
		for (int i = 0; i < 8; i++) {
			if ((crc & 0x0001) != 0) {
				crc >>= 1;
				crc ^= 0xA001;
			} else
				crc >>= 1;
		}
	}
	return crc;
}

// Đọc phản hồi Modbus cho Function 0x10
HAL_StatusTypeDef Modbus_ReadAck_0x10(UART_HandleTypeDef *huart,
		uint8_t expected_slave, uint16_t expected_start_addr,
		uint16_t expected_qty_reg, uint32_t timeout_ms) {
	uint8_t rx[8];
	HAL_StatusTypeDef st = HAL_UART_Receive(huart, rx, sizeof(rx), timeout_ms);
	if (st != HAL_OK)
		return st;

	uint16_t crc_calc = ModRTU_CRC(rx, 6);
	uint16_t crc_rx = (uint16_t) rx[6] | ((uint16_t) rx[7] << 8);
	if (crc_calc != crc_rx)
		return HAL_ERROR;

	uint8_t slave = rx[0];
	uint8_t func = rx[1];
	uint16_t addr = ((uint16_t) rx[2] << 8) | rx[3];
	uint16_t qty = ((uint16_t) rx[4] << 8) | rx[5];

	if (slave != expected_slave)
		return HAL_ERROR;
	if (func != 0x10)
		return HAL_ERROR;
	if (addr != expected_start_addr)
		return HAL_ERROR;
	if (qty != expected_qty_reg)
		return HAL_ERROR;

	return HAL_OK;
}

// Gửi nhiều giá trị float qua Modbus RTU
HAL_StatusTypeDef Send_ModbusRTU_Floats(UART_HandleTypeDef *huart,
		const float *vals, uint8_t count, uint16_t start_addr,
		mb_float_order_t order) {
	if (count == 0 || count > 5)
		return HAL_ERROR;

	const uint8_t slave_id = 0x01;
	uint16_t regs = count * 2;
	uint8_t byte_count = regs * 2;

	uint8_t txLen = 7 + byte_count + 2;
	uint8_t txBuf[7 + 20 + 2];

	txBuf[0] = slave_id;
	txBuf[1] = 0x10;
	txBuf[2] = (start_addr >> 8) & 0xFF;
	txBuf[3] = (start_addr) & 0xFF;
	txBuf[4] = (regs >> 8) & 0xFF;
	txBuf[5] = (regs) & 0xFF;
	txBuf[6] = byte_count;

	uint8_t *p = &txBuf[7];
	union {
		float f;
		uint8_t b[4];
	} fu;
	for (uint8_t i = 0; i < count; ++i) {
		fu.f = vals[i];
		encode_float_to_regs(p, fu, order);
		p += 4;
	}

	uint16_t crc = ModRTU_CRC(txBuf, txLen - 2);
	txBuf[txLen - 2] = crc & 0xFF;
	txBuf[txLen - 1] = (crc >> 8) & 0xFF;

	HAL_StatusTypeDef st = HAL_UART_Transmit(huart, txBuf, txLen, 100);
	if (st != HAL_OK)
		return st;

	return Modbus_ReadAck_0x10(huart, slave_id, start_addr, regs, 100);
}

// Gửi 1 giá trị float qua Modbus RTU
HAL_StatusTypeDef Send_ModbusRTU_Float(UART_HandleTypeDef *huart, float value,
		uint16_t start_addr) {
	union {
		float f;
		uint8_t u8[4];
	} float_union;
	float_union.f = value;

	uint8_t txBuf[13];
	const uint8_t slave_id = 0x01;

	txBuf[0] = slave_id;
	txBuf[1] = 0x10;
	txBuf[2] = (start_addr >> 8) & 0xFF;
	txBuf[3] = (start_addr) & 0xFF;
	txBuf[4] = 0x00;
	txBuf[5] = 0x02;
	txBuf[6] = 0x04;

	txBuf[7] = float_union.u8[1];
	txBuf[8] = float_union.u8[0];
	txBuf[9] = float_union.u8[3];
	txBuf[10] = float_union.u8[2];

	uint16_t crc = ModRTU_CRC(txBuf, 11);
	txBuf[11] = crc & 0xFF;
	txBuf[12] = (crc >> 8) & 0xFF;

	HAL_StatusTypeDef st = HAL_UART_Transmit(huart, txBuf, sizeof(txBuf), 100);
	if (st != HAL_OK)
		return st;

	return Modbus_ReadAck_0x10(huart, slave_id, start_addr, 0x0002, 100);
}
/* USER CODE END 4 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void) {
	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_USART1_UART_Init();
	/* USER CODE BEGIN 2 */

	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1) {
		/* USER CODE END WHILE */

		/* USER CODE BEGIN 3 */
		for (int i = 0; i < sizeof(temperatures) / sizeof(float); i++) {
			Send_ModbusRTU_Float(&huart1, temperatures[i], 0x0010 + i * 2);
			HAL_Delay(100);
		}
		HAL_Delay(1000);
	}
	/* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };

	/** Configure the main internal regulator output voltage
	 */
	__HAL_RCC_PWR_CLK_ENABLE();
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) {
		Error_Handler();
	}
}

/**
 * @brief USART1 Initialization Function
 * @param None
 * @retval None
 */
static void MX_USART1_UART_Init(void) {

	/* USER CODE BEGIN USART1_Init 0 */

	/* USER CODE END USART1_Init 0 */

	/* USER CODE BEGIN USART1_Init 1 */

	/* USER CODE END USART1_Init 1 */
	huart1.Instance = USART1;
	huart1.Init.BaudRate = 115200;
	huart1.Init.WordLength = UART_WORDLENGTH_8B;
	huart1.Init.StopBits = UART_STOPBITS_1;
	huart1.Init.Parity = UART_PARITY_NONE;
	huart1.Init.Mode = UART_MODE_TX_RX;
	huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart1.Init.OverSampling = UART_OVERSAMPLING_16;
	if (HAL_UART_Init(&huart1) != HAL_OK) {
		Error_Handler();
	}
	/* USER CODE BEGIN USART1_Init 2 */

	/* USER CODE END USART1_Init 2 */

}

/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */
static void MX_GPIO_Init(void) {
	/* USER CODE BEGIN MX_GPIO_Init_1 */

	/* USER CODE END MX_GPIO_Init_1 */

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOA_CLK_ENABLE();

	/* USER CODE BEGIN MX_GPIO_Init_2 */

	/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
// CRC16 MODBUS calculation
uint16_t ModRTU_CRC(uint8_t *buf, int len) {
	uint16_t crc = 0xFFFF;
	for (int pos = 0; pos < len; pos++) {
		crc ^= (uint16_t) buf[pos];
		for (int i = 0; i < 8; i++) {
			if (crc & 0x0001) {
				crc >>= 1;
				crc ^= 0xA001;
			} else {
				crc >>= 1;
			}
		}
	}
	return crc;
}

// gửi gtri dưới chuẩn Modbus RTU
void Send_ModbusRTU_Float(UART_HandleTypeDef *huart, float value,
		uint16_t start_addr) {
	float_union.f = value;

	uint8_t txBuf[13];
	txBuf[0] = 0x01; // Modbus Slave ID
	txBuf[1] = 0x10; // Function Code: Write Multiple Registers
	txBuf[2] = (start_addr >> 8) & 0xFF;
	txBuf[3] = start_addr & 0xFF;
	txBuf[4] = 0x00;
	txBuf[5] = 0x02;
	txBuf[6] = 0x04; // đếm byte

	// Lưu gtri theo kiểu Modbus
	txBuf[7] = float_union.u8[1];
	txBuf[8] = float_union.u8[0];
	txBuf[9] = float_union.u8[3];
	txBuf[10] = float_union.u8[2];

	uint16_t crc = ModRTU_CRC(txBuf, 11);
	txBuf[11] = crc & 0xFF;
	txBuf[12] = (crc >> 8) & 0xFF;

	HAL_UART_Transmit(huart, txBuf, 13, 100);
}
/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void) {
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
